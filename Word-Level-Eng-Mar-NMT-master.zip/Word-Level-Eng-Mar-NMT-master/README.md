# Word-Level-Eng-Mar-NMT

Please refer my blog for detailed explanation: https://medium.com/@harshall.lamba/word-level-english-to-marathi-neural-machine-translation-using-seq2seq-encoder-decoder-lstm-model-1a913f2dc4a7

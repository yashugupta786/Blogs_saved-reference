# NMT-with-Attention-Mechanism

Please read my blog for detailed understanding of the project https://towardsdatascience.com/intuitive-understanding-of-attention-mechanism-in-deep-learning-6c9482aecf4f 
